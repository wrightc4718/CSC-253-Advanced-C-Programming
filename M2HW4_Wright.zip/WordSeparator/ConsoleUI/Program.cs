﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleUI
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter the words you want separated. ");
            string input = Console.ReadLine();

            int wordSeparator = 0;
            int wordCount = 0;

            string[] wordArray = input.Split(' ');

            //for (int i = 0; i < input.Length; i++)
            {
                wordSeparator = input.Trim().Split(' ').Count();
            }
            foreach (string character in wordArray)
            {
                wordCount = character.Count();
            }
            Console.WriteLine("This is your sentence after the words are separated. " + wordCount);
            Console.ReadLine();
        }
    }
}
