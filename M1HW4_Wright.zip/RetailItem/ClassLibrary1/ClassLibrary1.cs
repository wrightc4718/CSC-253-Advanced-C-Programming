﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace ClassLibrary1
{
    public class Retail
    {
        
        
            private string _description;
            private int _unitsonhand;
            private string _price;

            public Retail()
            {
                Description = "";
                UnitsOnHand = 0;
                Price = "";

            }
            public string Description
            {
                get
                {
                    return _description;
                }
                set
                {
                    _description = value;
                }
            }
            public int UnitsOnHand
            {
                get
                {
                    return _unitsonhand;
                }
                set
                {
                    _unitsonhand = value;
                }
            }
            public string Price
            {
                get
                {
                    return _price;
                }
                set
                {
                    _price = value;
                }
            }
            
        
    }
}
