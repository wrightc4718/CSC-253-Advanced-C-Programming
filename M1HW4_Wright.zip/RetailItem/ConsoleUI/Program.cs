﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ClassLibrary1;

namespace ConsoleUI
{
    class Program
    {
        static void Main(string[] args)
        {
            Retail item1 = new Retail();

            item1.Description = "Jacket";
            item1.UnitsOnHand = 12;
            item1.Price = "$59.95";
            

            Console.WriteLine(item1.Description);
            Console.WriteLine(item1.UnitsOnHand);
            Console.WriteLine(item1.Price);
            


            Retail item2 = new Retail();

            item2.Description = "Jeans";
            item2.UnitsOnHand = 40;
            item2.Price = "$34.95";
           

            Console.WriteLine(item2.Description);
            Console.WriteLine(item2.UnitsOnHand);
            Console.WriteLine(item2.Price);
            

            Retail item3 = new Retail();

            item3.Description = "Shirt";
            item3.UnitsOnHand = 20;
            item3.Price = "$24.95";
           

            Console.WriteLine(item3.Description);
            Console.WriteLine(item3.UnitsOnHand);
            Console.WriteLine(item3.Price);
            

            Console.ReadLine();

        }
    }
}
