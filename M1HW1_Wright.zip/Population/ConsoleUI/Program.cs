﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleUI
{
    class Program
    {
        static void Main(string[] args)
        {
            {
            
                //decimal dailyIncrease = 2 * .30m;
                int numberofDays = 0;
                int startPopulation = 2;
                int numberofOrganisms = 2;
                decimal totalPopulation = 0;
                decimal dailyIncrease = .30m;

                bool exit = false;

                do
                {
                    Console.WriteLine("1. Run Program");
                    Console.WriteLine("2. Exit");
                    string input = Console.ReadLine();


                    if (input == "1")
                    {
                        Console.WriteLine("Enter the starting number of organisms. ");
                        input = Console.ReadLine();
                        Console.WriteLine("");

                        while (startPopulation < 2)
                        {
                            Console.WriteLine("The starting population can not be less than 2, please re-enter. ");
                            input = Console.ReadLine();

                        }

                        Console.WriteLine("Enter the number of days the population increases. ");
                        input = Console.ReadLine();
                        Console.WriteLine("");



                        int userCount = 1;


                        if (int.TryParse(input, out userCount))
                        {
                            for (int count = 1; count <= userCount; count++)
                            {
                                Console.WriteLine(" Day " + count + " Your daily population increase is " + totalPopulation);
                                //dailyIncrease *= 2 * .30m;
                                //Console.WriteLine("The total population " + totalPopulation);
                                //dailyIncrease 
                                totalPopulation = ( startPopulation + totalPopulation + dailyIncrease);
                            }
                            Console.WriteLine("");
                        }

                    }
                    else
                    {
                        exit = true;
                    }
                } while (exit == false);
            }
        }
    }
}
