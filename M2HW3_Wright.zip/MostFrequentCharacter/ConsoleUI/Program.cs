﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleUI
{
    class Program
    {
        static void Main(string[] args)
        {
            int count = 0;
            int totalCount = 0;
            string str;

            Console.WriteLine("Please enter your word or phrase. ");
            str = Console.ReadLine();

            
            int[] charCount = new int[256];
            int length = str.Length;
            for (int i = 0; i < length; i++)
            {
                charCount[str[i]]++;
            }
            
            char character = ' ';
            for (int i = 0; i < length; i++)
            {
                if (totalCount < charCount[str[i]])
                {
                    totalCount = charCount[str[i]];
                    character = str[i];
                }
            }
            Console.WriteLine("The string is " + str);
            Console.WriteLine("The most occuring character in the string is " + character);
            Console.WriteLine("The character occurs " + totalCount + " times. ");
            Console.ReadLine();
        }
    }
}
