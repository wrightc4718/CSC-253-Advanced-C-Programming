﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleUI
{
    class Program
    {
        static void Main(string[] args)
        {
            int daysinHospital = 0;
            double medicationCharges = 0;
            double surgicalCharges = 0;
            double labFees = 0;
            double rehabCharges = 0;
            double dailyCharge = 350;
            double stayCharge = 0;
            double miscCharge = 0;
            double totalCharges = 0;

            bool exit = false;

            do
            {
                Console.WriteLine("1. To Run Program");
                Console.WriteLine("2. To exit program");
                string input = Console.ReadLine();

                if (input == "1")
                {
                    Console.WriteLine("Enter the amount of days in the Hospital.");
                    input = Console.ReadLine();
                    Console.WriteLine("");

                    Console.WriteLine("Total stay charges is $" + stayCharge);
                    stayCharge = dailyCharge * daysinHospital;
                    double Input = double.Parse(input);
                    Console.WriteLine("Enter the amount of medication charges.");
                    input = Console.ReadLine();
                    Console.WriteLine("Enter the amount of surgical charges.");
                    input = Console.ReadLine();
                    Console.WriteLine("Enter the amount of lab fees.");
                    input = Console.ReadLine();
                    Console.WriteLine("Enter the amount of rehab charges.");
                    input = Console.ReadLine();
                    //double miscCharge = medicationCharges + surgicalCharges + labFees + rehabCharges;
                    Console.WriteLine("The total misc charges are? " + miscCharge);
                    miscCharge = medicationCharges + surgicalCharges + labFees + rehabCharges;
                    Console.WriteLine("The total hospital charges are. " + stayCharge + miscCharge);
                    totalCharges = dailyCharge + miscCharge;
                    Console.ReadLine();

                }           

            } while (exit == false);
        }
    }
}
