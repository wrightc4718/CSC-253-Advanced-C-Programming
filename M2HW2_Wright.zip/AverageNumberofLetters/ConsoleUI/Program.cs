﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleUI
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter the sentence you like to count. ");
            string input = Console.ReadLine();

            int wordCounter = 0;
            int charCount = 0;
            
            string[] charArray = input.Split(',');

            for (int i = 0; i < input.Length; i++)
            {
                wordCounter = input.Trim().Split(' ').Count();
            }
            foreach(string character  in charArray)
            {
                charCount = character.Count();
            }
            int average = charCount / wordCounter;
            Console.WriteLine("Your average number of letters is " + average);
            Console.ReadLine();
        }
    }
}
